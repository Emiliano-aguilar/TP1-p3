package WordleTp;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextPane;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.awt.event.ActionEvent;
import javax.swing.Timer;
import javax.swing.border.LineBorder;

import WordleTp.juegoInterno.estadoLetra;


public class Principal extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private Integer intentos = 6;
	private juegoInterno nuevo;
	private Integer segundos= 0 ,minutos = 0;
	JLabel lblNewLabel = new JLabel("00 : 00");
	
	private int x = 60;
	private int y = 90;
	
	private JTextPane[][] cuadritos = null;
	
	private int filas = 6;

	private int columnas = 5;
	
	private ActionListener accion= new ActionListener() {
		@Override
			public void actionPerformed(ActionEvent e) {
				segundos++;
				String ContadorDeTiempo="";
				

				if(minutos<10)
					ContadorDeTiempo += "0" + minutos;
				else
					ContadorDeTiempo += minutos;

				ContadorDeTiempo += " : ";
				
				if(segundos<10)
					ContadorDeTiempo += "0" + segundos;
				else
					ContadorDeTiempo += segundos;

				if (segundos == 59) {
					segundos = 0;
					minutos++;
				}
				
				lblNewLabel.setText(ContadorDeTiempo);
			}
		};
	    private Timer Crono = new Timer(1000,accion); //crean una accion cada cierto tiempo Timer(Milisengundos, MetodoDeAccion)

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Principal frame = new Principal();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Principal() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 620);
		contentPane = 	new JPanel();
		contentPane.setBackground(Color.BLUE);
		contentPane.setBorder(new LineBorder(new Color(0, 0, 0)));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		DateTimeFormatter Cronometro = DateTimeFormatter.ofPattern("HH:mm:ss");
	    String Reloj = Cronometro.format(LocalDateTime.now());
		Crono.start();
			
		nuevo = new juegoInterno();
		
		JLabel lblNewLabel_1 = new JLabel("WORDLE!");
		lblNewLabel_1.setFont(new Font("Times New Roman", Font.BOLD, 24));
		lblNewLabel_1.setForeground(Color.BLACK);
		lblNewLabel_1.setBounds(151, 26, 174, 40);
		contentPane.add(lblNewLabel_1);
		
		lblNewLabel.setBounds(329, 11, 83, 40);
		contentPane.add(lblNewLabel);
		lblNewLabel.setFont(new Font("Berlin Sans FB", Font.PLAIN, 24));
		lblNewLabel.setForeground(Color.YELLOW);		
		
		definirTamanio(filas,columnas);

		for (int i = 0; i < columnas; i++) {
			for (int j = 0; j < filas; j++) {
				inicializarCuadritos(j,i,x,y);
				y = y+70;	
			}
			x = x+70;
			y = 90;
		}
		
		JButton btnNewButton = new JButton("ACEPTAR");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
			if(intentos == 6) {
				String palabra = cuadritos[0][0].getText() + cuadritos[1][0].getText() + cuadritos[2][0].getText() + cuadritos[3][0].getText() + cuadritos[4][0].getText();
				if (palabraVacia(palabra)) {
					JOptionPane.showMessageDialog(null, "NO PUEDES INGRESAR UN CARACTER VACIO, NI UN CARACTER DOBLE");
					intentos++;
				}else{
					estadoLetra [] Estado = nuevo.compararPalabra(palabra);
					for (int i = 0; i < 5; i++) {
						pintaCasillas(Estado, i , 0 );
					}
					
				if(Estado[0].equals(estadoLetra.Correcto) && Estado[1].equals(estadoLetra.Correcto) && Estado[2].equals(estadoLetra.Correcto) && Estado[3].equals(estadoLetra.Correcto) && Estado[4].equals(estadoLetra.Correcto)) {
						JOptionPane.showMessageDialog(null, "FELICITACIONES, GANASTE. " + "LA PALABRA ERA: " + nuevo.getPalabraAdivinar()+ ". TU TIEMPO FUE DE: " + lblNewLabel.getText() );
						dispose();
				}
					
				}
			}
			

			if(intentos == 5) {
				String palabra = cuadritos[0][1].getText() + cuadritos[1][1].getText() + cuadritos[2][1].getText() + cuadritos[3][1].getText() + cuadritos[4][1].getText();
				if (palabraVacia(palabra)) {
					JOptionPane.showMessageDialog(null, "NO PUEDES INGRESAR UN CARACTER VACIO, NI UN CARACTER DOBLE");
					intentos++;
				}else{
					estadoLetra [] Estado = nuevo.compararPalabra(palabra);
					for (int i = 0; i < 5; i++) {
						pintaCasillas(Estado, i , 1 );
					}
					
				if(Estado[0].equals(estadoLetra.Correcto) && Estado[1].equals(estadoLetra.Correcto) && Estado[2].equals(estadoLetra.Correcto) && Estado[3].equals(estadoLetra.Correcto) && Estado[4].equals(estadoLetra.Correcto)) {
						JOptionPane.showMessageDialog(null, "FELICITACIONES, GANASTE. " + "LA PALABRA ERA: " + nuevo.getPalabraAdivinar()+ ". TU TIEMPO FUE DE: " + lblNewLabel.getText() );
						dispose();
				}
					
				}
			}

			if(intentos == 4) {
				String palabra = cuadritos[0][2].getText() + cuadritos[1][2].getText() + cuadritos[2][2].getText() + cuadritos[3][2].getText() + cuadritos[4][2].getText();
				if (palabraVacia(palabra)) {
					JOptionPane.showMessageDialog(null, "NO PUEDES INGRESAR UN CARACTER VACIO, NI UN CARACTER DOBLE");
					intentos++;
				}else{
					estadoLetra [] Estado = nuevo.compararPalabra(palabra);
					for (int i = 0; i < 5; i++) {
						pintaCasillas(Estado, i , 2 );
					}
					
				if(Estado[0].equals(estadoLetra.Correcto) && Estado[1].equals(estadoLetra.Correcto) && Estado[2].equals(estadoLetra.Correcto) && Estado[3].equals(estadoLetra.Correcto) && Estado[4].equals(estadoLetra.Correcto)) {
						JOptionPane.showMessageDialog(null, "FELICITACIONES, GANASTE. " + "LA PALABRA ERA: " + nuevo.getPalabraAdivinar()+ ". TU TIEMPO FUE DE: " + lblNewLabel.getText() );
						dispose();
				}
					
				}
			}
			

			if(intentos == 3) {
				String palabra = cuadritos[0][3].getText() + cuadritos[1][3].getText() + cuadritos[2][3].getText() + cuadritos[3][3].getText() + cuadritos[4][3].getText();
				if (palabraVacia(palabra)) {
					JOptionPane.showMessageDialog(null, "NO PUEDES INGRESAR UN CARACTER VACIO, NI UN CARACTER DOBLE");
					intentos++;
				}else{
					estadoLetra [] Estado = nuevo.compararPalabra(palabra);
					for (int i = 0; i < 5; i++) {
						pintaCasillas(Estado, i , 3 );
					}
					
				if(Estado[0].equals(estadoLetra.Correcto) && Estado[1].equals(estadoLetra.Correcto) && Estado[2].equals(estadoLetra.Correcto) && Estado[3].equals(estadoLetra.Correcto) && Estado[4].equals(estadoLetra.Correcto)) {
						JOptionPane.showMessageDialog(null, "FELICITACIONES, GANASTE. " + "LA PALABRA ERA: " + nuevo.getPalabraAdivinar()+ ". TU TIEMPO FUE DE: " + lblNewLabel.getText() );
						dispose();
				}
					
				}
			}
			

			if(intentos == 2) {
				String palabra = cuadritos[0][4].getText() + cuadritos[1][4].getText() + cuadritos[2][4].getText() + cuadritos[3][4].getText() + cuadritos[4][4].getText();
				if (palabraVacia(palabra)) {
					JOptionPane.showMessageDialog(null, "NO PUEDES INGRESAR UN CARACTER VACIO, NI UN CARACTER DOBLE");
					intentos++;
				}else{
					estadoLetra [] Estado = nuevo.compararPalabra(palabra);
					for (int i = 0; i < 5; i++) {
						pintaCasillas(Estado, i , 4 );
					}
					
				if(Estado[0].equals(estadoLetra.Correcto) && Estado[1].equals(estadoLetra.Correcto) && Estado[2].equals(estadoLetra.Correcto) && Estado[3].equals(estadoLetra.Correcto) && Estado[4].equals(estadoLetra.Correcto)) {
						JOptionPane.showMessageDialog(null, "FELICITACIONES, GANASTE. " + "LA PALABRA ERA: " + nuevo.getPalabraAdivinar()+ ". TU TIEMPO FUE DE: " + lblNewLabel.getText() );
						dispose();
				}
					
				}
			}
			

			if(intentos == 1) {
				String palabra = cuadritos[0][5].getText() + cuadritos[1][5].getText() + cuadritos[2][5].getText() + cuadritos[3][5].getText() + cuadritos[4][5].getText();
				if (palabraVacia(palabra)) {
					JOptionPane.showMessageDialog(null, "NO PUEDES INGRESAR UN CARACTER VACIO, NI UN CARACTER DOBLE");
					intentos++;
				}else{
					estadoLetra [] Estado = nuevo.compararPalabra(palabra);
					for (int i = 0; i < 5; i++) {
						pintaCasillas(Estado, i , 5 );
					}
					
				if(Estado[0].equals(estadoLetra.Correcto) && Estado[1].equals(estadoLetra.Correcto) && Estado[2].equals(estadoLetra.Correcto) && Estado[3].equals(estadoLetra.Correcto) && Estado[4].equals(estadoLetra.Correcto)) {
						JOptionPane.showMessageDialog(null, "FELICITACIONES, GANASTE. " + "LA PALABRA ERA: " + nuevo.getPalabraAdivinar()+ ". TU TIEMPO FUE DE: " + lblNewLabel.getText() );
						dispose();
				}
					
				}
			}
				
				intentos--;
				if (intentos == 0) {
					JOptionPane.showMessageDialog(null, "HAS PERDIDO. " + "LA PALABRA ERA: " + nuevo.getPalabraAdivinar());
					dispose();
				}
			
				
			}
			});
		btnNewButton.setBounds(162, 547, 89, 23);
		contentPane.add(btnNewButton);		
		

	}

//													METODOS PRIVADOS	
/*----------------------------------------------------------------------------------------------------------------------------------------------------*/

	private void pintaCasillas(estadoLetra[] Estado, int i, int j) {
	if (Estado[i].equals(estadoLetra.Correcto)) 
		cuadritos[i][j].setBackground(Color.GREEN);
	else if(Estado[i].equals(estadoLetra.CorrectoMalUbicado))
		cuadritos[i][j].setBackground(Color.YELLOW);
	else if(Estado[i].equals(estadoLetra.Mal))  
		cuadritos[i][j].setBackground(Color.GRAY);
	
	}

	private boolean palabraVacia(String palabra) {
		if (palabra.isEmpty()) {
			return true;
		}else if(palabra.length() > 5) {
			return true;
		}
		return false;
	}
	
	private void inicializarCuadritos(int i, int j, int x, int y) {
		cuadritos[j][i] = new JTextPane();
		cuadritos[j][i].setBounds(x, y, 30, 30);
		contentPane.add(cuadritos[j][i]);
	}

	private void definirTamanio(int i, int j) {
		cuadritos = new JTextPane[j][i];
	}
}